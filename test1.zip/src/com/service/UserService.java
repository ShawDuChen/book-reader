package com.service;
import java.util.List;
import com.entity.User;

public interface UserService{
   public void add(User user);          // 添加用户
   public void update(User user);        // 更新用户
   public void delete(long id);                // 删除用户
   public User findByName(String username, String password);   // 按姓名查找用户
   public User findById(long id);           // 按id查找用户
   public List<User> findAll();             // 查找全部用户
}


