package com.service;
import java.util.List;
import com.entity.User;
import com.dao.UserDAO;
public class UserServiceImpl implements UserService{
   private UserDAO userDao;
   // 注入DAO对象
   public void setUserDao(UserDAO userDao){
      this.userDao = userDao;
}
// 添加用户
public void add(User user){
     // 如果表中不包含该用户，则添加该用户
      if(userDao.findById(user.getId())==null)
        userDao.add(user);
}         
// 更新用户   
public void update(User user){
    // 如果表中存在该用户，则更新该用户
    if(userDao.findById(user.getId())!=null)
       userDao.update(user);
}
   // 删除用户
public void delete(long id){
      // 如果表中存在该用户，则删除该用户
    if(userDao.findById(id)!=null)
         userDao.delete(id);
    }                
// 按姓名查找用户
   public User findByName(String username,String password){
      return userDao.findByName(username,password);
}           
// 按id查找用户
   public User findById(long id){
      return userDao.findById(id);
}
// 查找全部用户
public List<User> findAll(){
      return userDao.findAll();
}            
}

