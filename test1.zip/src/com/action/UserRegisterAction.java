package com.action;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.entity.User;
import com.service.UserService;
import com.opensymphony.xwork2.ActionSupport;
public class UserRegisterAction extends ActionSupport{
   private User user;
   private UserService userService;
   public void setUser(User user){
      this.user = user;
   }
   public User getUser(){
      return user;
   }
   // 注入业务逻辑组件
   public void setUserService(UserService userService){
      this.userService = userService;
   }
   public String execute(){
      //System.out.println("User.ID="+user.getId());
      Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		user.setCreated(formatter.format(date));
      userService.add(user);
      return SUCCESS;
   } 
}

