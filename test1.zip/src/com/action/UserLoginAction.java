package com.action;
import com.entity.User;
import com.service.UserService;
import com.opensymphony.xwork2.ActionSupport;
public class UserLoginAction extends ActionSupport{
    private User user;
    private UserService userService;
    public User getUser() {
	   return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

    // 注入业务逻辑组件
    public void setUserService(UserService userService){
       this.userService = userService;
    }
    public String execute(){
    	System.out.println(user.getUsername());	
       System.out.println(userService); 
       System.out.println(user.getPassword());
    // 查找用户
     User mb = 
      userService.findByName(user.getUsername(),user.getPassword());
    if(mb !=null)
         return SUCCESS;
    else
       return ERROR;

   } 
}

