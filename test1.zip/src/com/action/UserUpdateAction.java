package com.action;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.entity.User;
import com.service.UserService;
import com.opensymphony.xwork2.ActionSupport;
public class UserUpdateAction extends ActionSupport{
   private UserService userService;
   private User user;
   // 用于接收从现实用户信息页面传递来的id
   private long id;
   // 注入业务逻辑组件
   public void setUserService(UserService userService){
      this.userService = userService;
   }
   public User getUser(){
      return user;
   }
   public void setUser(User user){
      this.user = user;
   }
   public long getId() {
	 return id;
   }
   public void setId(long id) {
	 this.id = id;
   }
   public String showUser(){
	 System.out.println("用户号="+getId());
	  User mb = userService.findById(getId());
      setUser(mb); 
      System.out.println("用户名="+user.getUsername());
      return SUCCESS;
	}


  public String execute(){
      Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		user.setUpdated(formatter.format(date));
      userService.update(user);
      return SUCCESS;
   }
}

