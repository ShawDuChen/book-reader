package com.action;
import com.service.UserService;
import com.opensymphony.xwork2.ActionSupport;
public class UserDeleteAction extends ActionSupport{
   private UserService userService;
// 注入业务逻辑组件
public void setUserService(UserService userService){
     this.userService = userService;
}
private long id;
public long getId(){
     return id;
}
public void setId(long id){
     this.id = id;
}
public String execute(){
    userService.delete(getId());
    return SUCCESS;
  }
}

