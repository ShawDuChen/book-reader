package com.action;
import java.util.List;
import org.apache.struts2.ServletActionContext;
import javax.servlet.http.HttpServletRequest;
import com.entity.User;
import com.service.UserService;
import com.opensymphony.xwork2.ActionSupport;
public class UserQueryAction extends ActionSupport{
   private UserService userService;
// 注入业务逻辑组件
public void setUserService(UserService userService){
      this.userService = userService;
}
public String execute(){
      List<User> list = userService.findAll();
       // 将所有用户信息存入request作用域中
      ServletActionContext.getRequest().setAttribute("userList",list);
      return SUCCESS;
}
}

