package com.dao;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.entity.User;

public class UserDAOImpl implements UserDAO{
   private SessionFactory sessionFactory;
 
   public UserDAOImpl(SessionFactory sessionFactory){
       this.sessionFactory = sessionFactory;
   }
    // 使用SessionFactory对象返回Session对象
   private Session currentSession(){
       return sessionFactory.openSession();
   }
   // 添加用户
   public void add(User user){
	   Session session=null;
	   try{
		  session = currentSession();
		  Transaction tx =session.beginTransaction();
		  System.out.println(user.getId());
		  System.out.println(user.getUsername());
		  session.save(user);
		  tx.commit();
	  }catch(HibernateException e){
		  e.printStackTrace();
	  }finally{
		  session.close();
	  }
      
}         
   // 更新用户
public void update(User user){
	Session session=null;
	try{
		 session = currentSession();
		  Transaction tx =session.beginTransaction();
		  session.update(user);
		  tx.commit();
	  }catch(HibernateException e){
		  e.printStackTrace();
	  }finally{
		  session.close();
	  }
      
}       
// 删除用户
   public void delete(long id){
	   Session session=null;
	   try{
		   session = currentSession();
		   Transaction tx =session.beginTransaction();
		   User mb = (User)session.get(User.class, id);
		   session.delete(mb);
		   System.out.println(mb);
		   tx.commit();
		}catch(HibernateException e){
			  e.printStackTrace();
		}finally{
			  session.close();
		}
	   
}                
// 按姓名和口令查找用户
   public User findByName(String username,String password){
	   Session session=null;
	   User result=null;
	   try{
		   session = currentSession();
		   Transaction tx =session.beginTransaction();
			String hsql="from User m where m.username=:musername and m.password=:mpassword";
		    Query query = session.createQuery(hsql);
		    query.setParameter("musername",username);
		    query.setParameter ("mpassword",password);
		    result = (User)query.uniqueResult();
		    tx.commit();
			  
		  }catch(HibernateException e){
			  e.printStackTrace();
		  }finally{
			  session.close();
		  }
	   return result;
   }    
   // 按id查找用户
public User findById(long id){
	Session session=null;
	User result=null;
	try{
		session = currentSession();
		  Transaction tx =session.beginTransaction();   
			String hsql="from User m where m.id=:id";
		    Query query = session.createQuery(hsql);
		    query.setParameter("id",id);
		    result = (User)query.uniqueResult();
		    tx.commit();  	    
	  }catch(HibernateException e){
		  e.printStackTrace();
	  }finally{
		  session.close();
	  }
	return result;
}          
// 查找全部用户
public List<User> findAll(){
	Session session=null;
	List<User> list = null; 
	
	try{
		session = currentSession();
		Transaction tx =session.beginTransaction();
		String hsql = "from User";
	    Query query = session.createQuery(hsql);
	    list = query.list();
	    tx.commit(); 
	 }catch(HibernateException e){
		e.printStackTrace();
	 }finally{
		 session.close();
	 }   
     return list;
   }            
}

