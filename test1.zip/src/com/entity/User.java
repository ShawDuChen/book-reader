package com.entity;

public class User{
  private long id;                 // 用户标识
  private String username;             // 用户名
  private String password;          // 用户口令
  private String nickname;            // 用户昵称
  private int sex;              // 用户性别
  private String birthday;                 // 用户级别
	private String created;
	private String updated;
  public User() {}
   
  public User(String username, String password, String nickname, int sex, String birthday, String created, String updated) {
		super();
		this.username = username;
		this.password = password;
		this.nickname = nickname;
		this.sex = sex;
		this.birthday = birthday;
		this.created = created;
		this.updated = updated;
	}

	// 这里省略各属性的setter方法和getter方法
	public long getId(){
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getNickname(){
		return nickname;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public int getSex(){
		return sex;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getBirthday(){
		return birthday;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public String getCreated(){
		return created;
	}

	public void setUpdated(String updated) {
		this.updated = updated;
	}

	public String getUpdated(){
		return updated;
	}

	public String toString(){
		return "用户ID="+getId()+"\n"
						+"用户姓名="+getUsername()+"\n"
						+"用户口令="+getPassword();
	}
}

